The following files were generated for 'lpf' in directory
D:\ModemPrograms\Chapter_4\E4_6_FirIpCore\FirIPCore\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * lpf.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * lpf.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * hex_lpf.mif
   * lpf.ngc
   * lpf.vhd
   * lpf.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * lpf.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * lpf.asy
   * lpf.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * lpf.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * lpf_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * lpf.gise
   * lpf.xise

Deliver Readme:
   Readme file for the IP.

   * lpf_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * lpf_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

