The following files were generated for 'bpf1' in directory
D:\ModemPrograms\Chapter_6\E6_5_FpgaFskDemod\fsk\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * bpf1.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * bpf1.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * bpf1.ngc
   * bpf1.vhd
   * bpf1.vho
   * hex_bpf1.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * bpf1.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * bpf1.asy
   * bpf1.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * bpf1.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * bpf1_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * bpf1.gise
   * bpf1.xise

Deliver Readme:
   Readme file for the IP.

   * bpf1_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * bpf1_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

