The following files were generated for 'mult8_8' in directory 
D:\ModemPrograms\Chapter_7\E7_2_FpgaCostas\ipcore_dir\

mult8_8_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

mult8_8.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

mult8_8.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

mult8_8.ise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

mult8_8.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

mult8_8.sym:
   Please see the core data sheet.

mult8_8.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

mult8_8.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

mult8_8.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

mult8_8.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

mult8_8.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

mult8_8.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

mult8_8_readme.txt:
   Text file indicating the files generated and how they are used.

mult8_8_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

