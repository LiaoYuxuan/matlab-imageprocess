The following files were generated for 'fir_lpf' in directory
D:\ModemPrograms\Chapter_7\E7_6_FpgaPolarCostas\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * fir_lpf.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * fir_lpf.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * fir_lpf.ngc
   * fir_lpf.vhd
   * fir_lpf.vho
   * fir_lpfCOEFF_auto0_0.mif
   * fir_lpfCOEFF_auto0_1.mif
   * fir_lpfCOEFF_auto0_2.mif
   * fir_lpfCOEFF_auto0_3.mif
   * fir_lpfCOEFF_auto0_4.mif
   * fir_lpffilt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * fir_lpf.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * fir_lpf.asy
   * fir_lpf.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * fir_lpf.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * fir_lpf_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * fir_lpf.gise
   * fir_lpf.xise

Deliver Readme:
   Readme file for the IP.

   * fir_lpf_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * fir_lpf_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

