The following files were generated for 'fi_lpf' in directory
D:\ModemPrograms\Chapter_7\E7_5_FpgaDqpsk\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * fi_lpf.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * fi_lpf.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * fi_lpf.ngc
   * fi_lpf.vhd
   * fi_lpf.vho
   * fi_lpfCOEFF_auto0_0.mif
   * fi_lpfCOEFF_auto0_1.mif
   * fi_lpfCOEFF_auto0_10.mif
   * fi_lpfCOEFF_auto0_11.mif
   * fi_lpfCOEFF_auto0_12.mif
   * fi_lpfCOEFF_auto0_13.mif
   * fi_lpfCOEFF_auto0_14.mif
   * fi_lpfCOEFF_auto0_15.mif
   * fi_lpfCOEFF_auto0_16.mif
   * fi_lpfCOEFF_auto0_2.mif
   * fi_lpfCOEFF_auto0_3.mif
   * fi_lpfCOEFF_auto0_4.mif
   * fi_lpfCOEFF_auto0_5.mif
   * fi_lpfCOEFF_auto0_6.mif
   * fi_lpfCOEFF_auto0_7.mif
   * fi_lpfCOEFF_auto0_8.mif
   * fi_lpfCOEFF_auto0_9.mif
   * fi_lpffilt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * fi_lpf.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * fi_lpf.asy
   * fi_lpf.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * fi_lpf.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * fi_lpf_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * fi_lpf.gise
   * fi_lpf.xise

Deliver Readme:
   Readme file for the IP.

   * fi_lpf_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * fi_lpf_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

