The following files were generated for 'dds500k' in directory
D:\ModemPrograms\Chapter_7\E7_7_FpgaDpskDemod\FpgaDqpskDemod\ipcore_dir\

Generate XCO file:
   CORE Generator input file containing the parameters used to generate a core.

   * dds500k.xco

Generate Implementation Netlist:
   Binary Xilinx implementation netlist files containing the information
   required to implement the module in a Xilinx (R) FPGA.

   * dds500k.ngc

Obfuscate Netlist Generator:
   Please see the core data sheet.

   * dds500k.ngc

Generate Instantiation Templates:
   Template files containing code that can be used as a model for instantiating
   a CORE Generator module in an HDL design.

   * dds500k.vho

RTL Simulation Model Generator:
   Please see the core data sheet.

   * dds500k.vhd

All Documents Generator:
   Please see the core data sheet.

   * dds500k/doc/dds_compiler_v4_0_vinfo.html
   * dds500k/doc/dds_ds558.pdf

Deliver IP Symbol:
   Graphical symbol information file. Used by the ISE tools and some third party
   tools to create a symbol representing the core.

   * dds500k.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * dds500k.sym

Generate XMDF file:
   ISE Project Navigator interface file. ISE uses this file to determine how the
   files output by CORE Generator for the core can be integrated into your ISE
   project.

   * dds500k_xmdf.tcl

Generate ISE project file:
   ISE Project Navigator support files. These are generated files and should not
   be edited directly.

   * _xmsgs/pn_parser.xmsgs
   * dds500k.gise
   * dds500k.xise

Deliver Readme:
   Readme file for the IP.

   * dds500k_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * dds500k_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

